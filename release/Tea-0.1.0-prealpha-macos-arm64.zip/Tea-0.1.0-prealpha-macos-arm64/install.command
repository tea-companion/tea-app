#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

fail() {
    printf '\nInstallation stopped: %s\n' "$1" >&2
    printf 'Press Return to close this window.\n' >&2
    read -r _answer
    exit 1
}

[ "$(uname -s)" = "Darwin" ] || fail "this preview supports macOS only"
[ "$(uname -m)" = "arm64" ] || fail "this preview supports Apple Silicon only"

command -v uv >/dev/null 2>&1 || fail "uv is required. Install it with: brew install uv"

printf 'Creating Tea\047s private Python environment...\n'
uv venv --python 3.10 .venv
uv pip install \
    --python .venv/bin/python \
    --cache-dir .cache/uv \
    "./tea_image-0.1.0-py3-none-any.whl[chat,app]"

mkdir -p local/data local/artifacts shared

printf '\nTea is installed. Double-click start.command to run it.\n'
