#!/usr/bin/env bash
# Provision a RunPod GPU pod to serve the Tea Krea 2 image pipeline.
#
# Runs at container start. Everything expensive lands on the persistent volume
# mounted at /workspace, so a stopped-and-restarted pod re-uses it instead of
# re-downloading 11 GB. Re-running this script is safe and is the normal path.
#
# Only /workspace survives a restart. Anything installed into the container
# filesystem (apt packages) is rebuilt from the image every time, so it must
# never be guarded by a marker stored on the volume.
#
# It never prints secrets. CIVITAI_TOKEN and TEA_COMFY_TOKEN arrive as env vars.
# -E matters as much as -e here: without errtrace the ERR trap below is NOT
# inherited by shell functions, so a curl failure inside fetch_asset skipped the
# park handler entirely, exited the script, and let RunPod restart the container
# into the same failure every ~90s. That is the exact loop the trap was written
# to prevent, and it went unnoticed because the trap looked correct.
set -Eeuo pipefail

WORKSPACE=${WORKSPACE:-/workspace}
COMFY_ROOT="$WORKSPACE/ComfyUI"
VENV="$WORKSPACE/venv"
STATE="$WORKSPACE/.tea"
# The log lives on the CONTAINER disk, not on $WORKSPACE, and that is
# load-bearing. It used to be at "$WORKSPACE/tea-bootstrap.log", which meant an
# unmounted or unwritable volume took out the log at the same moment it took
# out the boot - so the pod died with nothing to read, and RunPod restarted it
# into the same silence. That cost 29 minutes of a RUNNING pod on 2026-09-03
# with no way to see why. The container disk is always present, so the log is
# always writable, and a volume failure is now diagnosable rather than mute.
#
# It also stops being an append across boots, which is a small bonus: the file
# is now this boot's log rather than every boot's, so `+Ns` is unambiguous.
#
# All four diagnostic artefacts move together - this log, ComfyUI's log, the
# proxy script and the proxy's own log - because the proxy is what serves
# /tea/log and it resolves them from one root. Moving three of the four would
# leave /tea/log reading a path nothing writes to, which looks like an empty
# log rather than a misconfigured one. COMFY_ROOT is untouched: the models and
# the venv still belong on the volume, and only the diagnostics come off it.
LOGDIR=/tmp
LOG="$LOGDIR/tea-bootstrap.log"

COMFYUI_REPO=${COMFYUI_REPO:-https://github.com/Comfy-Org/ComfyUI.git}
# The commit arrives from the client, out of `assets.COMFYUI_COMMIT`, which is
# the only copy of it. Deliberately no fallback value: a literal here is the
# second copy that indirection exists to delete, and it is the copy that fails
# invisibly - the pod boots happily on a stale commit while this machine runs
# the new one, and both ends report success. Checked at the checkout below,
# where `say` and the log exist to fail loudly into.
COMFYUI_COMMIT=${TEA_COMFYUI_COMMIT:-}
COMFY_INTERNAL_PORT=8189   # ComfyUI itself, bound to loopback only
COMFY_PUBLIC_PORT=8188     # the authenticating proxy RunPod exposes
OLLAMA_INTERNAL_PORT=11434 # the chat model, loopback only, same as ComfyUI

# Which chat model this pod serves, or empty for "this pod serves no chat".
#
# No literal and no default, for the reason TEA_COMFYUI_COMMIT carries none: a
# model name here would be a second copy of one the app already holds, and the
# copy that fails invisibly - the pod pulls one model while the app asks for
# another, and both ends report success. It arrives from
# `TEA_CHAT_CLOUD_MODEL`, which is also what the app's cloud placement asks
# for, so the two cannot disagree.
#
# Unlike TEA_COMFYUI_COMMIT, *unset is not fatal*: it is a real answer. This
# script boots both pods, and tea-video has no business pulling 8.6 GB of
# language model it will never load. Absent means skip the whole block.
POD_CHAT_MODEL=${TEA_POD_CHAT_MODEL:-}
# Ollama and its models live on the volume, not the container filesystem, so a
# stop/start does not re-download either. Only /workspace survives.
OLLAMA_HOME="$WORKSPACE/ollama"
OLLAMA_BIN="$OLLAMA_HOME/bin/ollama"

# A download that stops sending bytes must fail, not wait: on 2026-09-02 a
# stalled LoRA transfer held a boot for an hour, because --retry only fires
# once curl gives up and nothing made it. Script-level rather than local to
# `fetch_asset`, because the Ollama fetch needs exactly the same floor and a
# second copy is how one of the two drifts. `tests/test_runpod.py` pins that
# every curl in this script uses it.
CURL_STALL="--connect-timeout 30 --speed-limit 51200 --speed-time 60 --retry 5 --retry-delay 10 --retry-all-errors"

# ORDER MATTERS FOR THE NEXT THIRTY LINES. Logging, then the error trap, then
# the first touch of $WORKSPACE - in that order and no other.
#
# It used to be the other way round: `mkdir -p "$STATE"` and the `tee` of this
# log both wrote to $WORKSPACE *before* the trap existed. So a volume that was
# not mounted, or not writable, failed under `set -e` with no trap armed: the
# script exited, the container exited, RunPod restarted it, and it did the same
# thing again roughly every 90 seconds with nothing readable anywhere. The two
# cheapest lines in the file were the two that could not afford to fail, and
# they were the first two to run.
exec > >(tee -a "$LOG") 2>&1

# Every line carries the wall clock and the seconds since this boot started.
# Only the "starting" line used to have a time, so a 3-4 minute boot was one
# opaque number and every claim about where it went was read off this script
# rather than measured. $SECONDS is bash's own count from shell start, so the
# elapsed figure needs nothing kept up to date.
say() { echo "[tea-bootstrap] $(date -Is) +${SECONDS}s $*"; }

say "starting (log on the container disk at $LOG)"

# On failure, do NOT let the container exit. RunPod would restart it into the
# same failure and the log would be unreachable, which is precisely how the
# first two failures went undiagnosed. Park instead, so /tea/log still answers.
#
# `|| true` on the marker: it lives on $WORKSPACE, and the whole point of
# arming this trap early is to survive a $WORKSPACE that cannot be written. A
# park that dies trying to record that it parked is not a park.
on_error() {
  local line=$1
  say "FATAL: bootstrap failed at line $line. The pod stays up for diagnosis."
  touch "$STATE/failed" 2>/dev/null || say "(could not write $STATE/failed - is $WORKSPACE mounted?)"
  sleep infinity
}
trap 'on_error $LINENO' ERR

# Prove the volume before trusting it. Every substitution is `|| true` because
# under `set -e` a failing command inside `$( )` aborts the boot, and
# `mountpoint` is not present in every base image. Lifted from
# scripts/probe_volume_boot.py, which needed exactly this to diagnose a silent
# pod and is where the ordering above was worked out.
say "workspace: $(ls -ld "$WORKSPACE" 2>&1 | tr -s ' ' || true)"
say "workspace mountpoint: $(mountpoint "$WORKSPACE" 2>&1 || true)"
say "workspace df: $(df -h "$WORKSPACE" 2>&1 | tail -1 || true)"
if touch "$WORKSPACE/.tea-write-probe" 2>/dev/null; then
  say "workspace is WRITABLE"
  rm -f "$WORKSPACE/.tea-write-probe" || true
else
  say "workspace is NOT WRITABLE - this is the failure that used to be silent"
fi
# What survived to this boot, said out loud. On a network volume both should be
# `yes` on every boot after the first, and a `no` here is the single most useful
# line in the log for explaining a slow boot.
say "venv present before this boot: $([ -x "$VENV/bin/python" ] && echo yes || echo no)"
say "deps marker before this boot: $([ -f "$VENV/.tea-deps-installed" ] && echo yes || echo no)"

mkdir -p "$STATE"

# --- system packages ---------------------------------------------------------
# Deliberately NOT guarded by a marker file on $WORKSPACE. Only the volume
# survives a stop/start; the container filesystem is rebuilt from the image, so
# a persisted "apt.done" would skip an install whose packages are already gone
# and fail later on a missing git. Probe the binaries instead.
missing_packages=()
for binary in git curl; do
  command -v "$binary" >/dev/null 2>&1 || missing_packages+=("$binary")
done
python3 -c "import venv" >/dev/null 2>&1 || missing_packages+=("python3-venv")

if [ ${#missing_packages[@]} -gt 0 ]; then
  say "installing system packages: ${missing_packages[*]}"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq ca-certificates "${missing_packages[@]}" >/dev/null
else
  say "system packages already present in the image"
fi

# --- authenticating proxy ----------------------------------------------------
# ComfyUI has no authentication of its own, and a RunPod proxy URL is public to
# anyone who learns the pod id. ComfyUI therefore binds to loopback and every
# request must carry the bearer token.
cat > "$LOGDIR/tea_proxy.py" <<'PROXY'
import hashlib
import hmac
import json
import os
import shutil
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

UPSTREAM = f"http://127.0.0.1:{os.environ.get('COMFY_INTERNAL_PORT', '8189')}"
# The chat model, behind the same bearer auth and on the same public port.
# Ollama has no authentication of its own either, and an unauthenticated one on
# a public RunPod URL is an open LLM for anyone who learns the pod id.
LLM_UPSTREAM = f"http://127.0.0.1:{os.environ.get('OLLAMA_INTERNAL_PORT', '11434')}"
LLM_PREFIX = "/tea/llm"
# Longer than FORWARD_TIMEOUT because generation legitimately takes minutes on a
# long reply, where nothing ComfyUI serves does. Applies between reads, and a
# streaming response produces a line per token, so this bounds a *stalled*
# generation rather than a slow one.
LLM_TIMEOUT = 600
TOKEN = os.environ.get("TEA_COMFY_TOKEN", "")
MODELS = Path(os.environ.get("COMFY_ROOT", "/workspace/ComfyUI")) / "models"
ALLOWED_SUBDIRS = {"diffusion_models", "text_encoders", "vae", "loras"}
# Nothing ComfyUI serves needs minutes: /prompt returns at once and progress is
# polled. A long timeout only hides a dead upstream behind the edge proxy.
FORWARD_TIMEOUT = 120
WORKSPACE = Path(os.environ.get("WORKSPACE", "/workspace"))
# The client's label for the config this pod booted with: a hash of the
# bootstrap script and the asset plan. The pod does not compute it, it only
# reports it back, so there is exactly one implementation of the hash and no
# way for the two ends to disagree about the algorithm.
CONFIG_HASH = os.environ.get("TEA_CONFIG_HASH", "")
LOGS = {
    "bootstrap": WORKSPACE / "tea-bootstrap.log",
    "comfyui": WORKSPACE / "comfyui.log",
    "proxy": WORKSPACE / "tea-proxy.log",
    # The fourth diagnostic artefact, for the same reason the other three are
    # here: without it a chat model that will not start is a 502 with no shell
    # on the pod to ask why.
    "ollama": WORKSPACE / "ollama.log",
}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):  # keep the pod log readable
        pass

    def _authorised(self) -> bool:
        header = self.headers.get("Authorization", "")
        supplied = header.removeprefix("Bearer ").strip()
        # Constant-time compare so the token cannot be probed by timing.
        return bool(TOKEN) and hmac.compare_digest(supplied, TOKEN)

    def _deny(self):
        self.send_response(401)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _upload(self):
        """Receive a model file the pod cannot fetch for itself."""
        parts = self.path.split("/")
        # /tea/upload/<subdir>/<filename>?sha256=...
        if len(parts) < 5:
            self.send_error(400, "expected /tea/upload/<subdir>/<filename>")
            return
        # unquote: the client percent-encodes the filename segment, because a
        # pinned asset name is whatever its uploader typed and several contain
        # spaces. Without decoding here the file is written as "a%20b.safetensors"
        # and the request still answers 200 - a silent wrong-name write, which is
        # worse than the InvalidURL the encoding was added to fix.
        subdir = parts[3]
        filename = urllib.parse.unquote(parts[4].split("?")[0])
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        expected = (query.get("sha256") or [""])[0]
        if subdir not in ALLOWED_SUBDIRS or "/" in filename or ".." in filename:
            self.send_error(400, "bad destination")
            return
        target = MODELS / subdir / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        length = int(self.headers.get("Content-Length", "0"))
        digest = hashlib.sha256()
        tmp = target.with_suffix(target.suffix + ".partial")
        remaining = length
        with tmp.open("wb") as handle:
            while remaining > 0:
                chunk = self.rfile.read(min(1 << 20, remaining))
                if not chunk:
                    break
                digest.update(chunk)
                handle.write(chunk)
                remaining -= len(chunk)
        got = digest.hexdigest()
        if expected and got != expected:
            tmp.unlink(missing_ok=True)
            self.send_error(422, f"sha256 mismatch: {got}")
            return
        shutil.move(str(tmp), str(target))
        body = f'{{"stored":"{filename}","sha256":"{got}"}}'.encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _have(self):
        """Answer whether the pod already holds a file, by digest.

        Without this the client re-uploads every local-only asset on every pod
        start, because it has no way to ask. That was invisible while no such
        asset existed; the first one is 469 MB, and the network volume means a
        recreate is now a routine, automatic event rather than a rare one - so
        the upload, not the boot, would have become the slow part.
        """
        parts = self.path.split("/")
        if len(parts) < 5:
            self.send_error(400, "expected /tea/have/<subdir>/<filename>")
            return
        # unquote: the client percent-encodes the filename segment, because a
        # pinned asset name is whatever its uploader typed and several contain
        # spaces. Without decoding here the file is written as "a%20b.safetensors"
        # and the request still answers 200 - a silent wrong-name write, which is
        # worse than the InvalidURL the encoding was added to fix.
        subdir = parts[3]
        filename = urllib.parse.unquote(parts[4].split("?")[0])
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        expected = (query.get("sha256") or [""])[0]
        if subdir not in ALLOWED_SUBDIRS or "/" in filename or ".." in filename:
            self.send_error(400, "bad destination")
            return
        target = MODELS / subdir / filename
        present = False
        if expected and target.is_file():
            digest = hashlib.sha256()
            with target.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            # Compared, not trusted: a half-written file from an interrupted
            # upload is exactly the case that must still re-upload.
            present = digest.hexdigest() == expected
        body = json.dumps({"present": present}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _forward(self, method: str):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else None
        request = urllib.request.Request(f"{UPSTREAM}{self.path}", data=body, method=method)
        for name, value in self.headers.items():
            if name.lower() not in {"host", "authorization", "content-length"}:
                request.add_header(name, value)
        try:
            with urllib.request.urlopen(request, timeout=FORWARD_TIMEOUT) as response:
                payload = response.read()
                self.send_response(response.status)
                for name, value in response.headers.items():
                    if name.lower() not in {"transfer-encoding", "content-length", "connection"}:
                        self.send_header(name, value)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except urllib.error.URLError:
            self.send_error(502, "ComfyUI is not answering")

    def _forward_llm(self, method: str):
        """Relay to Ollama, streaming, with the /tea/llm prefix stripped.

        Separate from `_forward` for a reason that is not cosmetic: that one
        reads the whole upstream response before writing a byte. Ollama's chat
        API answers NDJSON, one JSON object per token, and Tea depends on
        receiving it as it is produced. `reply_stream` is the entire
        perceived-latency win, and `_chat_abortable` hands the model back
        mid-generation the instant a reply wants it (`tea_chat/model_gate.py`)
        by closing the connection. Buffering here would turn the first into a
        wait for the last token and the second into a no-op, and both would
        look like the pod simply being slow.

        Iterating the response yields a line at a time, which is the natural
        chunk for NDJSON - `read(n)` would block for a full buffer and
        re-introduce exactly the stall this avoids.
        """
        path = self.path[len(LLM_PREFIX) :] or "/"
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else None
        request = urllib.request.Request(f"{LLM_UPSTREAM}{path}", data=body, method=method)
        for name, value in self.headers.items():
            if name.lower() not in {"host", "authorization", "content-length"}:
                request.add_header(name, value)
        try:
            with urllib.request.urlopen(request, timeout=LLM_TIMEOUT) as response:
                self.send_response(response.status)
                for name, value in response.headers.items():
                    if name.lower() not in {
                        "transfer-encoding",
                        "content-length",
                        "connection",
                    }:
                        self.send_header(name, value)
                # Chunked, because the length is unknowable until generation
                # ends and HTTP/1.1 needs one or the other.
                self.send_header("Transfer-Encoding", "chunked")
                self.end_headers()
                for line in response:
                    self.wfile.write(b"%x\r\n%s\r\n" % (len(line), line))
                    self.wfile.flush()
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except urllib.error.URLError:
            # Distinct wording from ComfyUI's 502 on purpose: on this pod the
            # two upstreams fail independently, and "ComfyUI is not answering"
            # when the chat model is the dead one would send the reader to the
            # wrong log.
            self.send_error(502, "the chat model is not answering")
        except (BrokenPipeError, ConnectionResetError):
            # The client hung up mid-generation. That is not a fault - it is
            # `_chat_abortable` giving the GPU back to a waiting reply, by
            # design, and it is supposed to happen often.
            pass

    def _serve_log(self):
        """Return the tail of a pod log so failures are diagnosable remotely.

        Without this the only symptom of a dead ComfyUI is a timeout, and there
        is no shell on the pod from the client's side.
        """
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        name = (query.get("name") or ["bootstrap"])[0]
        lines = int((query.get("tail") or ["200"])[0])
        path = LOGS.get(name)
        if path is None:
            self.send_error(404, f"unknown log {name}")
            return
        try:
            text = path.read_text(errors="replace")
        except OSError as exc:
            text = f"<could not read {path}: {exc}>"
        body = "\n".join(text.splitlines()[-lines:]).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle(self, method: str):
        if self.path == "/tea/health":
            body = json.dumps({"ok": True, "config": CONFIG_HASH}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if not self._authorised():
            self._deny()
            return
        if self.path.startswith("/tea/upload/") and method == "PUT":
            self._upload()
            return
        if self.path.startswith("/tea/have/") and method == "GET":
            self._have()
            return
        if self.path.startswith("/tea/log") and method == "GET":
            self._serve_log()
            return
        # Ahead of the catch-all, which forwards everything else to ComfyUI.
        if self.path.startswith(LLM_PREFIX):
            self._forward_llm(method)
            return
        self._forward(method)

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")


if __name__ == "__main__":
    port = int(os.environ.get("COMFY_PUBLIC_PORT", "8188"))
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
PROXY


pkill -f "tea_proxy.py" 2>/dev/null || true
say "starting authenticating proxy on :$COMFY_PUBLIC_PORT (before provisioning, so /tea/log works throughout)"
COMFY_ROOT="$COMFY_ROOT" \
COMFY_INTERNAL_PORT="$COMFY_INTERNAL_PORT" \
COMFY_PUBLIC_PORT="$COMFY_PUBLIC_PORT" \
OLLAMA_INTERNAL_PORT="$OLLAMA_INTERNAL_PORT" \
WORKSPACE="$LOGDIR" \
TEA_COMFY_TOKEN="${TEA_COMFY_TOKEN:-}" \
TEA_CONFIG_HASH="${TEA_CONFIG_HASH:-}" \
nohup python3 "$LOGDIR/tea_proxy.py" >> "$LOGDIR/tea-proxy.log" 2>&1 &
sleep 2

# --- ComfyUI at a pinned commit ---------------------------------------------
# Stopping a pod kills whatever git was doing, leaving index.lock behind on the
# persistent volume. Every later boot then failed here, exited, and was
# restarted by RunPod into the same failure - a crash loop that looks exactly
# like a slow boot from outside. Clear the stale locks and only fetch when the
# ref we want is genuinely absent.
ensure_ref() {
  local dir="$1" ref="$2"
  rm -f "$dir/.git/index.lock" "$dir/.git/shallow.lock" "$dir/.git/HEAD.lock" 2>/dev/null || true
  if ! git -C "$dir" rev-parse --verify --quiet "${ref}^{commit}" >/dev/null 2>&1; then
    git -C "$dir" fetch --quiet --all --tags
  fi
  git -C "$dir" checkout --quiet --force "$ref"
}

# Unset means the client sent no pin, and is fatal for the same reason an
# unsent node recipe is: there is nothing sane to fall back to. Checking out
# whatever is at HEAD would serve a different ComfyUI than this machine's, and
# the pod would look perfectly healthy doing it.
[ -n "$COMFYUI_COMMIT" ] \
  || { say "FATAL: TEA_COMFYUI_COMMIT is unset: no ComfyUI pin was sent"; exit 1; }

if [ ! -d "$COMFY_ROOT/.git" ]; then
  say "cloning ComfyUI"
  git clone --filter=blob:none "$COMFYUI_REPO" "$COMFY_ROOT"
fi
ensure_ref "$COMFY_ROOT" "$COMFYUI_COMMIT"
say "ComfyUI at $(git -C "$COMFY_ROOT" rev-parse --short HEAD)"

# --- python environment ------------------------------------------------------
# --system-site-packages is load-bearing. The requirements install below drops
# torch so the image's CUDA-matched build is used, but a plain venv cannot see
# it, so ComfyUI would start with no torch at all and exit immediately.
make_venv() {
  say "creating venv with access to the image's torch"
  rm -rf "$VENV"
  python3 -m venv --system-site-packages "$VENV"
}

[ -x "$VENV/bin/python" ] || make_venv
# Importability is not enough. A RunPod pod migration copies /workspace to a
# new host and can leave a partially-written torch in the venv's site-packages:
# `import torch` still succeeds, because the package directory exists, but the
# module is hollow and `torch.__version__` raises. That shadows the image's
# working CUDA torch and killed a boot here on 2026-08-30. Probe an attribute a
# real torch always has, so a hollow one is rebuilt instead of failing later.
# WHY this probe fires matters as much as THAT it fires, because the response
# is `rm -rf "$VENV"` and a full requirements rebuild - ~14 of the 19m17s a
# migration cost on 2026-09-03. The probe touches `torch.cuda`, which reaches
# the driver, so a host whose GPU is not ready at bootstrap time could fail it
# on a perfectly healthy venv and we would pay fourteen minutes to fix nothing.
# Nobody has ever seen the error text: the rebuild was inferred from the gap in
# the log. Record it, so a false positive is visible instead of assumed.
if ! torch_probe=$("$VENV/bin/python" -c "import torch; torch.__version__; torch.cuda" 2>&1); then
  say "venv torch probe FAILED: $(echo "$torch_probe" | tail -1)"
  say "rebuilding the venv - this is the ~14 minute path"
  make_venv
else
  say "venv torch probe passed; keeping the existing venv"
fi
PY="$VENV/bin/python"
say "torch $("$PY" -c 'import torch; print(torch.__version__, torch.cuda.is_available())')"
# Where torch is loaded FROM, which the log has never said. It should be the
# image's site-packages: `--system-site-packages` exists so the CUDA-matched
# build in the image is used and nothing that large lands on the volume. A path
# under $VENV means something installed torch into the venv - which both bloats
# the volume and creates the very copy the probe above exists to catch being
# corrupted. The comment explaining that failure says "a partially-written
# torch in the venv's site-packages", so if this line ever says the venv, that
# comment is describing a bug rather than a fact of migration.
say "torch loaded from: $("$PY" -c 'import torch; print(torch.__file__)' 2>&1)"
if "$PY" -c "import torch,sys; sys.exit(0 if '$VENV' in torch.__file__ else 1)" 2>/dev/null; then
  say "torch is INSIDE the venv - unexpected; it should come from the image"
else
  say "torch comes from the image, as intended"
fi

# The base image ships torch but NOT torchvision/torchaudio, and ComfyUI imports
# torchaudio unconditionally. Install only what is genuinely missing, from the
# CUDA index matching the installed torch, with --no-deps so pip cannot quietly
# swap the image's CUDA torch for a PyPI build.
TORCH_VERSION=$("$PY" -c 'import torch; print(torch.__version__.split("+")[0])')
CUDA_TAG=$("$PY" -c 'import torch; print("cu" + (torch.version.cuda or "").replace(".", ""))')
TORCH_INDEX="https://download.pytorch.org/whl/${CUDA_TAG:-cu121}"

install_torch_sibling() {
  local module="$1" pin="$2"
  if "$PY" -c "import $module" >/dev/null 2>&1; then
    say "$module already available"
    return 0
  fi
  say "installing $module from $TORCH_INDEX"
  "$PY" -m pip install --quiet --no-deps --index-url "$TORCH_INDEX" "$module==$pin" \
    || "$PY" -m pip install --quiet --no-deps --index-url "$TORCH_INDEX" "$module" \
    || "$PY" -m pip install --quiet --no-deps "$module"
  "$PY" -c "import $module; print('$module', $module.__version__)" \
    || { say "FATAL: $module still not importable"; return 1; }
}

# torchaudio tracks torch's version exactly; torchvision does not, so it is
# resolved by the index rather than pinned.
install_torch_sibling torchaudio "$TORCH_VERSION"
install_torch_sibling torchvision "$TORCH_VERSION"

# Once per venv, not once per boot: the upgrade used to reach the network on
# every boot to conclude pip was already current. What it is actually for is
# stopping a *fresh* venv installing the requirements below with whatever pip
# the base image ships, which is a property of the venv and not of the boot.
#
# It is a marker rather than a line inside make_venv, so that an interrupted
# venv build is healed instead of inherited. A pod stopped between `python3 -m
# venv` and this line leaves $VENV/bin/python executable and importable, so the
# next boot skips make_venv entirely - and would then have installed the
# requirements with the un-upgraded pip exactly once, invisibly. Stopping a pod
# mid-mutation is not hypothetical here; it is what left an index.lock on the
# disk and crash-looped every later boot.
PIP_MARKER="$VENV/.tea-pip-upgraded"
if [ ! -f "$PIP_MARKER" ]; then
  say "upgrading pip once for this venv"
  "$PY" -m pip install --quiet --upgrade pip
  touch "$PIP_MARKER"
fi

# The marker lives inside the venv so the two are deleted together; a marker
# outside it could claim deps were installed into a venv that no longer exists.
DEPS_MARKER="$VENV/.tea-deps-installed"
if [ ! -f "$DEPS_MARKER" ]; then
  # The base image already ships a CUDA-matched torch; let pip keep it.
  grep -viE '^(torch|torchvision|torchaudio)([=<>~!]|$)' "$COMFY_ROOT/requirements.txt" \
    > /tmp/comfy-reqs.txt
  # Bracketed by two `say` lines carrying the requirement count, because this
  # block is the single largest unexplained cost in the whole boot: ~14 minutes
  # of the 19m17s migration, and a local A/B on the same requirement set
  # installs it in 100s. That 8x gap is unexplained, and subtracting these two
  # timestamps is what will explain it. Deliberately still `pip`: swapping in
  # `uv` (measured 1.9x locally) would change the variable being measured.
  say "installing ComfyUI requirements: $(grep -cvE '^\s*(#|$)' /tmp/comfy-reqs.txt) lines, with pip $("$PY" -m pip --version | awk '{print $2}')"
  "$PY" -m pip install --quiet -r /tmp/comfy-reqs.txt
  say "ComfyUI requirements installed"
  touch "$DEPS_MARKER"
fi

# --- custom nodes, from the pod's recipe -------------------------------------
# The node requirements get the same treatment ComfyUI's own already had via
# $DEPS_MARKER, and for the same reason: resolving a satisfied dependency set is
# not free. Impact-Subpack pulls ultralytics, which is slow to resolve even when
# every package is already installed, and it was re-resolved on every boot only
# because nobody had given the node packs the marker the main requirements have.
#
# The marker is keyed on the pinned ref, so bumping a node re-installs its deps
# rather than trusting the last ref's. It lives inside the venv so the two are
# deleted together - a marker outside it could claim deps were installed into a
# venv that no longer exists.
install_node() {
  local name="$1" repo="$2" ref="$3"
  local dir="$COMFY_ROOT/custom_nodes/$name"
  if [ ! -d "$dir/.git" ]; then
    say "cloning custom node $name"
    git clone --quiet "$repo" "$dir"
  fi
  ensure_ref "$dir" "$ref"
  if [ -f "$dir/requirements.txt" ]; then
    local node_marker="$VENV/.tea-node-deps-$name"
    if [ "$(cat "$node_marker" 2>/dev/null || true)" = "$ref" ]; then
      say "$name requirements already installed for $ref"
    else
      say "installing $name requirements"
      "$PY" -m pip install --quiet -r "$dir/requirements.txt"
      # Advisory, like the asset markers: an unwritable one costs the next boot
      # a re-install, where taking the ERR trap would cost a parked pod.
      printf '%s\n' "$ref" > "$node_marker" 2>/dev/null || true
    fi
  fi
  say "$name at $(git -C "$dir" rev-parse --short HEAD)"
}

# Which nodes to install arrives as JSON from the client, the way the asset plan
# does, because it is a property of what this pod serves and not of this script.
# The image pod sends four; the video pod sends none, since every class_type in
# the Wan workflow ships with ComfyUI - it used to clone all four, ultralytics
# included, and use none of them. Keeping the list here also tied every pod's
# TEA_CONFIG_HASH to every other pod's pins: bumping an image node marked a warm
# tea-video pod stale, and that reboot re-verifies 39 GB.
#
# An *unset* recipe is a client that failed to send one, and installing nothing
# would boot a pod that fails its first generation with an unrecognised
# class_type. That is worth the ERR trap; an empty list is not, it is an answer.
#
# Note this is stricter than TEA_ASSETS_JSON below, which defaults to "[]" when
# unset. The two should agree and today they do not; nothing has decided which
# way. Unreachable either way while the script and the env travel together out
# of `_bootstrap_env`, which is what makes it a tidy-up and not a bug.
python3 - <<'NODES' > /tmp/tea-custom-nodes.tsv
import json, os, sys
raw = os.environ.get("TEA_CUSTOM_NODES_JSON")
if raw is None:
    sys.exit("TEA_CUSTOM_NODES_JSON is unset: no custom node recipe was sent")
for name, repo, ref in json.loads(raw):
    print("\t".join([name, repo, ref]))
NODES

# A `while` loop whose input redirect fails is *skipped*, and takes neither the
# ERR trap nor `set -e` with it - so a missing plan would boot a pod with no
# custom nodes and no complaint, which is the one failure here that looks
# healthy. Checked in a condition context, where a false answer is an answer.
[ -f /tmp/tea-custom-nodes.tsv ] \
  || { say "FATAL: the custom node plan was not written"; exit 1; }

# Counted in the loop rather than with `wc -l` in a $( ): a command substitution
# that trips the ERR trap runs on_error's `sleep infinity` *inside the subshell*,
# which hangs the boot on a billing pod instead of parking it legibly.
#
# `|| [ -n "$name" ]` is what handles a plan whose last line has no trailing
# newline: `read` fails at EOF having already filled the variables, so the
# obvious loop installs every node but the last one and says nothing. python's
# `print` always terminates the line, so this is a guard against the next thing
# that writes this file rather than against today's writer.
installed_nodes=0
while IFS=$'\t' read -r name repo ref || [ -n "$name" ]; do
  # Fatal, not skipped. This is the loop that must fail loudly: a node the
  # workflow names and the pod lacks is an unrecognised class_type at the first
  # generation, long after anyone is reading the boot log.
  [ -n "$name" ] || { say "FATAL: empty entry in the custom node plan"; exit 1; }
  install_node "$name" "$repo" "$ref"
  installed_nodes=$((installed_nodes + 1))
done < /tmp/tea-custom-nodes.tsv
say "custom node recipe: $installed_nodes installed for this pod"

# --- model assets ------------------------------------------------------------
# Every file is verified by SHA-256 after transfer. A mismatch removes the file
# and fails the boot rather than letting a wrong checkpoint serve traffic.
#
# Re-hashing was the largest single thing a warm boot did: 11.4 GB on the pod's
# persistent disk, digest-verified on arrival and never written again. So a file
# that has already been proven correct is not re-proven by reading every byte,
# it is checked three cheap ways instead - and the property that matters is
# kept, because a file that has *never* been proven is still hashed in full.
#
# The marker records the digest a file was last verified against, and its size
# at that moment. That catches:
#
#   - a missing file, and a truncated one, via the size;
#   - a re-pin: a sha256 that changed in config/loras.json while the disk still
#     holds the old bytes under the same filename. This is why the marker
#     stores the digest rather than a bare "verified" flag - without it, the
#     wrong weights would serve silently, which is worse than a slow boot.
#
# What it deliberately does not catch: bytes that changed while the size did
# not. Only the disk silently corrupting itself can do that - each file is
# written to .partial, moved into place only once its digest matched, and never
# written again - so it is the one failure mode being traded away, knowingly,
# for the boot time. The deep "re-hash everything and tell me what is wrong"
# check belongs on the pod card and is still on the roadmap, unbuilt: a check
# that runs when someone remembers is not what belongs on every boot anyway.
#
# Full hashing still happens on arrival, on any mismatch, and for any file that
# has no marker yet - including one the client uploaded through the proxy, which
# writes no marker, so its first boot hashes it and every boot after is cheap.
#
# The markers live under $STATE and not beside the models, because ComfyUI's
# own model listing would otherwise find them: `folder_paths.recursive_search`
# excludes `.git` and nothing else, so a sidecar keeping the .safetensors
# extension comes back from `get_filename_list` as a model whose name happens
# to start with a dot-directory. Nothing in Tea reads that list today, which is
# exactly the kind of "inert until it isn't" that a dot-directory looks safe for.
asset_size() {
  # GNU stat, because the pod is Ubuntu. `wc -c < file` is portable but is not
  # guaranteed to skip reading the file, which is the entire cost being removed.
  # It prints nothing on failure rather than a placeholder: a placeholder would
  # compare equal to the one recorded in the marker and silently retire the
  # size check, which is the opposite of failing safe.
  stat -c %s "$1" 2>/dev/null
}

marker_agrees() {
  local dest="$1" marker="$2" sha="$3"
  [ -f "$marker" ] || return 1
  local recorded_sha recorded_size size
  read -r recorded_sha recorded_size < "$marker" 2>/dev/null || return 1
  [ "$recorded_sha" = "$sha" ] || return 1
  # `size=$(...)` takes the substitution's exit status, so the `||` is not
  # decoration: without it a missing file fails the assignment, and errexit is
  # only suspended here because every caller is an `if` condition.
  size=$(asset_size "$dest") || return 1
  [ -n "$size" ] || return 1
  [ "$recorded_size" = "$size" ] || return 1
}

# The marker is a cache, so writing one must never be able to fail the boot.
# Without the guards below a full disk or a read-only remount would take the
# ERR trap - which parks the pod at $1/hr, forever, over an advisory file, for
# an asset that verified correctly seconds earlier. A marker that cannot be
# written costs the next boot one full hash, which is the old behaviour.
write_marker() {
  local dest="$1" marker="$2" sha="$3" size
  # Called outside a condition, so errexit is live and every one of these `||`s
  # is what stops an advisory write from parking the pod. A failing command
  # substitution fails the assignment too, which is not obvious by reading.
  size=$(asset_size "$dest") || return 0
  [ -n "$size" ] || return 0
  mkdir -p "$(dirname "$marker")" 2>/dev/null || return 0
  printf '%s %s\n' "$sha" "$size" > "$marker" 2>/dev/null || return 0
}

fetch_asset() {
  local subdir="$1" name="$2" sha="$3" url="$4" auth="${5:-}"
  local dir="$COMFY_ROOT/models/$subdir"
  local dest="$dir/$name"
  local marker="$STATE/digests/$subdir/$name.sha256"
  mkdir -p "$dir"

  if [ -f "$dest" ]; then
    if marker_agrees "$dest" "$marker" "$sha"; then
      say "$name present and unchanged since it verified"
      return 0
    fi
    local have
    have=$(sha256sum "$dest" | cut -d' ' -f1)
    if [ "$have" = "$sha" ]; then
      say "$name already present and verified by full hash (no usable marker)"
      write_marker "$dest" "$marker" "$sha"
      return 0
    fi
    say "$name digest mismatch on disk; refetching"
    rm -f "$dest" "$marker"
  fi

  if [ -z "$url" ]; then
    say "$name has no remote source; awaiting upload from the client"
    return 0
  fi

  say "downloading $name"
  # --no-progress-meter, because this log is the only window into a slow boot
  # and curl's meter writes a line per second per asset. On 2026-09-02 an 11.9
  # GB fetch filled the entire 15 KB /tea/log window with progress bars: not a
  # single [tea-bootstrap] line survived, so the endpoint POD_OPERATIONS calls
  # the way to tell "broken" from "slow" could answer neither. `say` already
  # reports each asset starting and finishing; that is the signal.
  local tmp="$dest.partial"
  # A download that stops sending bytes must fail, not wait. On 2026-09-02 a
  # Backblaze transfer of one 230 MB LoRA stalled at 08:10 and the boot sat on
  # it for an hour: --retry only fires when curl gives up, and without a speed
  # floor curl never does. Under 50 KB/s for 60 s now counts as failure, and
  # --retry-all-errors lets the retry restart it. A boot that cannot fetch an
  # asset should say so within minutes, not hold a pod at $1/hr in silence.
  if [ -n "$auth" ]; then
    curl -fL --no-progress-meter $CURL_STALL \
      -H "Authorization: Bearer $auth" -o "$tmp" "$url"
  else
    curl -fL --no-progress-meter $CURL_STALL -o "$tmp" "$url"
  fi

  local got
  got=$(sha256sum "$tmp" | cut -d' ' -f1)
  if [ "$got" != "$sha" ]; then
    rm -f "$tmp"
    say "FATAL: $name sha256 $got does not match expected $sha"
    exit 1
  fi
  mv "$tmp" "$dest"
  write_marker "$dest" "$marker" "$sha"
  say "$name verified"
}

# The asset list arrives as JSON from the client, derived from the profile in
# use. Adding a checkpoint is therefore a profile change, never a change here.
python3 - <<'PLAN' > /tmp/tea-assets.tsv
import json, os
for a in json.loads(os.environ.get("TEA_ASSETS_JSON", "[]")):
    print("\t".join([a["subdir"], a["filename"], a["sha256"], a.get("url", ""),
                      a.get("auth", "")]))
PLAN

while IFS=$'\t' read -r subdir name sha url auth_kind; do
  [ -z "$name" ] && continue
  auth=""
  # Character LoRAs live in a private HF repo - they are a real person's
  # likeness - and a private repo 401s an unauthenticated fetch, which fails
  # the whole boot. The token here is the read-scoped one; the pod downloads
  # and never publishes.
  [ "$auth_kind" = "civitai" ] && auth="${CIVITAI_TOKEN:-}"
  [ "$auth_kind" = "hf" ] && auth="${HF_TOKEN:-}"
  fetch_asset "$subdir" "$name" "$sha" "$url" "$auth"
done < /tmp/tea-assets.tsv

# Anything with no locatable URL is still uploaded by the client through the
# proxy's authenticated /tea/upload endpoint - see fetch_asset's empty-url
# branch. Nothing is in that state today; publishing beats pushing by two
# orders of magnitude and scripts/publish_character_lora.py is how.

# --- launch ------------------------------------------------------------------
pkill -f "ComfyUI/main.py" 2>/dev/null || true
sleep 1

say "starting ComfyUI on loopback:$COMFY_INTERNAL_PORT"
cd "$COMFY_ROOT"
# CUDA defaults, deliberately unlike the Mac: no --cpu-vae, no --reserve-vram,
# and the model cache left on so weights stay resident between seeds.
nohup "$PY" main.py \
  --listen 127.0.0.1 \
  --port "$COMFY_INTERNAL_PORT" \
  --disable-auto-launch \
  --preview-method none \
  --use-pytorch-cross-attention \
  --database-url "sqlite:///:memory:" \
  >> "$LOGDIR/comfyui.log" 2>&1 &
COMFY_PID=$!

# A backgrounded ComfyUI that dies on startup is otherwise invisible: the proxy
# still answers /tea/health and the client just times out with no explanation.
sleep 20
if kill -0 "$COMFY_PID" 2>/dev/null; then
  say "ComfyUI process $COMFY_PID alive after 20s"
else
  say "ERROR: ComfyUI exited during startup. Last lines of comfyui.log:"
  tail -n 40 "$LOGDIR/comfyui.log" | sed 's/^/[comfyui] /'
fi


say "ready; models in $COMFY_ROOT/models"
touch "$STATE/ready"

# --- chat model, when this pod serves one ------------------------------------
# Deliberately AFTER `ready`. Images are what this pod exists for and what the
# client waits on; pulling 8.6 GB of language model must never sit in front of
# that. Chat simply arrives a few minutes into the pod's life, and the proxy
# answers 502 on /tea/llm until it does - which the app surfaces as "the cloud
# chat model isn't reachable", already the right message.
#
# Every failure in here is logged and swallowed. A pod that serves images
# perfectly must not be parked at $1/hr because a language model would not
# download; that is a strictly worse outcome than no chat. `serve_chat_model`
# is therefore always called in a condition context, which also suspends
# errexit inside it.
serve_chat_model() {
  mkdir -p "$OLLAMA_HOME/bin" "$OLLAMA_HOME/models"

  # Probing the binary rather than a marker, for the reason the apt block gives:
  # markers live on the volume and so does this, but a half-extracted tarball
  # would leave a marker claiming an install that cannot run.
  if [ ! -x "$OLLAMA_BIN" ]; then
    say "installing Ollama onto the volume (once; it survives a stop/start)"
    local tgz="$OLLAMA_HOME/ollama.tgz"
    curl -fL --no-progress-meter $CURL_STALL \
      -o "$tgz" "https://ollama.com/download/ollama-linux-amd64.tgz" || return 1
    tar -xzf "$tgz" -C "$OLLAMA_HOME" || return 1
    rm -f "$tgz" || true
  fi
  [ -x "$OLLAMA_BIN" ] || { say "Ollama is not executable at $OLLAMA_BIN"; return 1; }

  # The tarball ships its own CUDA runtime beside the binary; without this it
  # falls back to CPU, which for a 12B is slow enough to defeat the entire
  # reason for running chat on a GPU pod at all.
  export LD_LIBRARY_PATH="$OLLAMA_HOME/lib/ollama:${LD_LIBRARY_PATH:-}"
  export OLLAMA_MODELS="$OLLAMA_HOME/models"
  export OLLAMA_HOST="127.0.0.1:$OLLAMA_INTERNAL_PORT"

  pkill -f "ollama serve" 2>/dev/null || true
  sleep 1
  say "starting Ollama on loopback:$OLLAMA_INTERNAL_PORT"
  nohup "$OLLAMA_BIN" serve >> "$LOGDIR/ollama.log" 2>&1 &

  local ready=no
  for _ in $(seq 1 60); do
    if curl -fsS "http://127.0.0.1:$OLLAMA_INTERNAL_PORT/api/version" >/dev/null 2>&1; then
      ready=yes
      break
    fi
    sleep 1
  done
  if [ "$ready" != "yes" ]; then
    say "Ollama did not answer within 60s. Last lines of ollama.log:"
    tail -n 20 "$LOGDIR/ollama.log" | sed 's/^/[ollama] /' || true
    return 1
  fi
  say "Ollama answering"

  # -F: the model name contains no globbing metacharacters today, but it is a
  # user-supplied string and a literal match is what is meant.
  if "$OLLAMA_BIN" list 2>/dev/null | grep -Fq "$POD_CHAT_MODEL"; then
    say "chat model already on the volume: $POD_CHAT_MODEL"
    return 0
  fi
  say "pulling chat model $POD_CHAT_MODEL (several GB, once - it lands on the volume)"
  "$OLLAMA_BIN" pull "$POD_CHAT_MODEL" || return 1
  say "chat model ready: $POD_CHAT_MODEL"
}

if [ -z "$POD_CHAT_MODEL" ]; then
  # Not a failure. The video pod sends no chat model and must not spend minutes
  # and gigabytes on one it will never load.
  say "no chat model requested for this pod; skipping Ollama"
elif serve_chat_model; then
  say "chat model serving on /tea/llm"
else
  say "WARNING: the chat model did not come up. Images are unaffected; the app"
  say "         will report the cloud chat host as unreachable until it does."
fi

sleep infinity
