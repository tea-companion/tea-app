Tea Companion 0.1.0 — macOS Apple Silicon pre-alpha
==========================================================

Tea is an unfinished, terminal-assisted preview for adults. Keep this entire
folder together: Tea stores its settings, conversations and generated media
inside it.

Requirements
------------

1. Apple Silicon Mac.
2. Homebrew: https://brew.sh
3. Install the two required tools:

       brew install uv ollama

4. Start Ollama and install Tea's default chat model:

       ollama serve
       ollama pull hf.co/TheDrummer/Rocinante-X-12B-v1-GGUF:Q4_K_M

   The Ollama macOS app may be used instead of `ollama serve`.

Install and start
-----------------

1. Double-click install.command and allow it to finish.
2. Double-click start.command. Tea will open in your default browser.
3. Keep the Terminal window open while using Tea. Closing it stops Tea.

If macOS refuses to open a command, Control-click it, choose Open, then confirm.

Optional GPU media
------------------

Images and video can use your own RunPod account. Add your RunPod and Civitai
keys under Settings -> API keys. Video measurement also needs:

       brew install ffmpeg

This preview does not provision local ComfyUI or voice, and it begins with no
optional image or motion LoRAs. ChatGPT subscription image tools are disabled.

Privacy and cost
----------------

Tea requires no Tea account or subscription. Local application data stays in
this folder. Provider requests go directly from your Mac to providers you
configure, and any provider charges are between you and that provider.

Help
----

Email teacompanion@proton.me and mention that you are using version 0.1.0.
