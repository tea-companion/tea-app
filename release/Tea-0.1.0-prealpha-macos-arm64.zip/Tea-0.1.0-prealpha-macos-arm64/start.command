#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

if [ ! -x .venv/bin/tea-app ]; then
    printf 'Tea is not installed yet. Double-click install.command first.\n' >&2
    printf 'Press Return to close this window.\n' >&2
    read -r _answer
    exit 1
fi

mkdir -p local/data local/artifacts shared
export TEA_PUBLIC_BUILD=1

.venv/bin/tea-app &
tea_pid=$!

cleanup() {
    kill "$tea_pid" 2>/dev/null || true
    wait "$tea_pid" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

attempt=0
while [ "$attempt" -lt 60 ]; do
    if ! kill -0 "$tea_pid" 2>/dev/null; then
        wait "$tea_pid"
        exit $?
    fi
    if /usr/bin/curl -fsS http://127.0.0.1:8420/ >/dev/null 2>&1; then
        /usr/bin/open http://127.0.0.1:8420/
        wait "$tea_pid"
        status=$?
        trap - EXIT INT TERM
        exit "$status"
    fi
    sleep 0.25
    attempt=$((attempt + 1))
done

printf 'Tea did not become ready at http://127.0.0.1:8420/.\n' >&2
exit 1
